import { useState, type FormEvent } from 'react';
import { Building2, Eye, EyeOff, ShieldCheck, UserRound, KeyRound, ArrowRight, Sun, Moon, LoaderCircle, CheckCircle2 } from 'lucide-react';
import { useStore } from '../store';
import type { UserProfile } from '../lib/supabase';

type AccessRole = UserProfile['role'];
type Props = { onEntrar: (profile: UserProfile) => void };

const roles: { id: AccessRole; label: string; icon: typeof UserRound; hint: string }[] = [
  { id: 'morador', label: 'Morador', icon: UserRound, hint: 'Acompanhe sua unidade e o condomínio' },
  { id: 'sindico', label: 'Síndico', icon: Building2, hint: 'Acesse ferramentas de gestão' },
  { id: 'portaria', label: 'Portaria', icon: ShieldCheck, hint: 'Controle acessos e encomendas' },
  { id: 'admin', label: 'Administrador', icon: KeyRound, hint: 'Gerencie usuários e permissões' },
];

export default function Login({ onEntrar }: Props) {
  const { state, toggleTema } = useStore();
  const [cadastro, setCadastro] = useState(false);
  const [role, setRole] = useState<AccessRole>('morador');
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [mensagem, setMensagem] = useState('');
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setErro(''); setMensagem(''); setCarregando(true);
    try {
      const { supabase } = await import('../lib/supabase');
      if (!supabase) throw new Error('O Supabase ainda não está configurado. Preencha as chaves no arquivo .env.local.');
      if (cadastro) {
        if (role === 'admin') throw new Error('O acesso administrador só pode ser concedido por um administrador existente.');
        const { data, error: authError } = await supabase.auth.signUp({
          email: email.trim(), password: senha,
          options: { data: { nome: nome.trim(), requested_role: role } },
        });
        if (authError) throw authError;
        if (data.session && data.user) {
          const { data: profile, error: profileError } = await supabase.from('user_profiles').select('*').eq('id', data.user.id).single();
          if (profileError) throw profileError;
          if (role !== 'morador') {
            await supabase.auth.signOut();
            setMensagem('Cadastro recebido! O administrador precisa aprovar seu acesso como ' + roles.find((item) => item.id === role)?.label + '.');
            return;
          }
          onEntrar(profile as UserProfile);
        } else {
          setMensagem('Enviamos um link de confirmação para seu e-mail. Depois de confirmar, faça login para acessar sua conta.');
        }
      } else {
        const { data, error: authError } = await supabase.auth.signInWithPassword({ email: email.trim(), password: senha });
        if (authError) throw authError;
        const { data: profile, error: profileError } = await supabase.from('user_profiles').select('*').eq('id', data.user.id).single();
        if (profileError) throw profileError;
        if (profile.role !== role) {
          await supabase.auth.signOut();
          throw new Error(profile.role === 'morador' && profile.requested_role && profile.requested_role !== 'morador'
            ? 'Seu cadastro está aguardando aprovação do administrador.'
            : 'Esta conta não possui acesso como ' + (roles.find((item) => item.id === role)?.label ?? role) + '.');
        }
        onEntrar(profile as UserProfile);
      }
    } catch (e) {
      setErro(e instanceof Error ? e.message : 'Não foi possível concluir. Confira seus dados e tente novamente.');
    } finally { setCarregando(false); }
  };

  const activeRole = roles.find((item) => item.id === role)!;
  return (
    <div className="min-h-screen bg-[#f7f6f3] px-4 py-7 text-[#1e211e] lg:grid lg:grid-cols-[1fr_1fr] lg:gap-8 lg:px-8">
      <section className="relative hidden overflow-hidden rounded-[2rem] bg-[#1e302d] p-12 text-white lg:flex lg:min-h-[calc(100vh-3.5rem)] lg:flex-col lg:justify-between">
        <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full border border-white/10" /><div className="absolute -right-6 -top-6 h-60 w-60 rounded-full border border-white/10" />
        <div className="relative flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#dd704c]"><Building2 size={22} /></span><span className="text-xl font-extrabold tracking-tight">DOMU</span></div>
        <div className="relative max-w-lg"><p className="mb-5 text-sm font-semibold uppercase tracking-[.2em] text-[#f5b79e]">Seu condomínio, em harmonia</p><h1 className="text-5xl font-semibold leading-[1.12] tracking-tight">Um lugar melhor começa com uma boa gestão.</h1><p className="mt-6 max-w-md text-lg leading-8 text-white/70">Comunicação, rotina e cuidado reunidos em um só lugar.</p></div>
        <div className="relative flex items-center gap-3 text-sm text-white/60"><span className="h-2 w-2 rounded-full bg-[#e99570]" /> Feito para a vida em condomínio</div>
        <div className="pointer-events-none absolute bottom-28 right-12 h-40 w-40 rounded-[2.5rem] border border-white/10 rotate-12" />
      </section>

      <section className="mx-auto flex w-full max-w-[470px] flex-col justify-center py-4 lg:max-w-[500px] lg:px-8">
        <div className="mb-8 flex items-center justify-between lg:mb-10"><div className="flex items-center gap-2 lg:hidden"><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#dd704c] text-white"><Building2 size={18} /></span><span className="font-extrabold tracking-tight">DOMU</span></div><div className="hidden lg:block" />
          <button onClick={toggleTema} aria-label="Alternar tema" className="rounded-full border border-black/10 bg-white p-2.5 text-[#434b45] hover:bg-[#f3eee9]">{state.tema === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button>
        </div>
        <div className="mb-7"><p className="mb-2 text-sm font-semibold text-[#bb5b3d]">{cadastro ? 'COMECE POR AQUI' : 'BEM-VINDO DE VOLTA'}</p><h2 className="text-3xl font-semibold tracking-tight">{cadastro ? 'Crie sua conta' : 'Acesse sua conta'}</h2><p className="mt-2 text-sm text-[#707771]">{cadastro ? 'Informe seus dados para solicitar acesso ao condomínio.' : 'Entre com seu e-mail e senha para continuar.'}</p></div>
        <div className="mb-6"><p className="mb-2.5 text-sm font-semibold">Entrar como</p><div className="grid grid-cols-2 gap-2 sm:grid-cols-4">{roles.filter((item) => !cadastro || item.id !== 'admin').map((item) => { const Icon = item.icon; const selected = role === item.id; return <button type="button" key={item.id} onClick={() => setRole(item.id)} className={'flex min-h-[68px] flex-col items-center justify-center gap-1 rounded-2xl border p-2 text-xs font-semibold ' + (selected ? 'border-[#cf6a4b] bg-[#faeee9] text-[#91442d] shadow-sm' : 'border-[#e7e6e1] bg-white text-[#626a64] hover:border-[#cfc9c2]')}><Icon size={17} />{item.label}</button>; })}</div><p className="mt-2 text-xs text-[#7c827d]">{activeRole.hint}</p></div>
        <form onSubmit={submit} className="space-y-4">
          {cadastro && <label className="block text-sm font-medium">Nome completo<input autoComplete="name" required value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Como podemos chamar você?" className="mt-1.5 h-12 w-full rounded-xl border border-[#e5e4df] bg-white px-4 text-sm outline-none transition focus:border-[#c86b4f] focus:ring-4 focus:ring-[#c86b4f]/10" /></label>}
          <label className="block text-sm font-medium">E-mail<input autoComplete="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@exemplo.com" className="mt-1.5 h-12 w-full rounded-xl border border-[#e5e4df] bg-white px-4 text-sm outline-none transition focus:border-[#c86b4f] focus:ring-4 focus:ring-[#c86b4f]/10" /></label>
          <label className="block text-sm font-medium">Senha<span className="relative mt-1.5 block"><input autoComplete={cadastro ? 'new-password' : 'current-password'} type={mostrarSenha ? 'text' : 'password'} required minLength={8} value={senha} onChange={(e) => setSenha(e.target.value)} placeholder="Mínimo de 8 caracteres" className="h-12 w-full rounded-xl border border-[#e5e4df] bg-white px-4 pr-12 text-sm outline-none focus:border-[#c86b4f] focus:ring-4 focus:ring-[#c86b4f]/10" /><button type="button" onClick={() => setMostrarSenha((v) => !v)} aria-label={mostrarSenha ? 'Ocultar senha' : 'Mostrar senha'} className="absolute right-3 top-3.5 text-[#7b817c]">{mostrarSenha ? <EyeOff size={18} /> : <Eye size={18} />}</button></span></label>
          {erro && <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-3.5 py-3 text-sm text-red-700">{erro}</p>}
          {mensagem && <p role="status" className="flex gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-3 text-sm text-emerald-800"><CheckCircle2 size={18} className="shrink-0" />{mensagem}</p>}
          <button disabled={carregando} className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#c86648] px-4 text-sm font-semibold text-white shadow-sm transition hover:bg-[#b4573c] disabled:cursor-wait disabled:opacity-70">{carregando ? <LoaderCircle size={18} className="animate-spin" /> : <>{cadastro ? 'Solicitar acesso' : 'Entrar'} <ArrowRight size={17} /></>}</button>
        </form>
        <p className="mt-6 text-center text-sm text-[#737a74]">{cadastro ? 'Já tem uma conta?' : 'Ainda não tem uma conta?'} <button onClick={() => { setCadastro(!cadastro); setErro(''); setMensagem(''); }} className="font-semibold text-[#a95036] hover:underline">{cadastro ? 'Fazer login' : 'Criar conta'}</button></p>
        <p className="mt-8 text-center text-xs leading-5 text-[#919791]">Ao continuar, você concorda com os termos de uso e a política de privacidade do condomínio.</p>
      </section>
    </div>
  );
}
