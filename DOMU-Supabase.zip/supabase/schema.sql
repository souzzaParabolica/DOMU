-- Execute uma vez no SQL Editor do Supabase.
create extension if not exists pgcrypto;

do $$ begin
  create type public.domu_role as enum ('morador', 'sindico', 'portaria', 'admin');
exception when duplicate_object then null;
end $$;

create table if not exists public.user_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  nome text not null default '',
  role public.domu_role not null default 'morador',
  requested_role public.domu_role,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint user_profiles_no_admin_request check (requested_role is distinct from 'admin'::public.domu_role)
);

create or replace function public.domu_is_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.user_profiles p where p.id = (select auth.uid()) and p.role = 'admin');
$$;
revoke all on function public.domu_is_admin() from public;
grant execute on function public.domu_is_admin() to authenticated;

create or replace function public.domu_create_profile()
returns trigger language plpgsql security definer set search_path = '' as $$
declare requested public.domu_role;
begin
  begin
    requested := (new.raw_user_meta_data ->> 'requested_role')::public.domu_role;
  exception when others then
    requested := 'morador';
  end;
  if requested = 'admin' then requested := 'morador'; end if;
  insert into public.user_profiles (id, email, nome, role, requested_role, approved_at)
  values (new.id, coalesce(new.email, ''), coalesce(new.raw_user_meta_data ->> 'nome', ''), 'morador', requested,
    case when requested = 'morador' then now() else null end)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists domu_auth_user_created on auth.users;
create trigger domu_auth_user_created after insert on auth.users
for each row execute procedure public.domu_create_profile();

create or replace function public.domu_sync_profile_email()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  update public.user_profiles set email = coalesce(new.email, ''), updated_at = now() where id = new.id;
  return new;
end;
$$;
drop trigger if exists domu_auth_user_email_changed on auth.users;
create trigger domu_auth_user_email_changed after update of email on auth.users
for each row when (old.email is distinct from new.email)
execute procedure public.domu_sync_profile_email();

create or replace function public.domu_touch_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end; $$;
drop trigger if exists domu_profile_updated on public.user_profiles;
create trigger domu_profile_updated before update on public.user_profiles
for each row execute procedure public.domu_touch_updated_at();

alter table public.user_profiles enable row level security;
revoke all on public.user_profiles from anon, authenticated;
grant select on public.user_profiles to authenticated;
grant update (role, approved_at) on public.user_profiles to authenticated;

drop policy if exists "Users see own profile or admins see all" on public.user_profiles;
create policy "Users see own profile or admins see all"
  on public.user_profiles for select to authenticated
  using (id = (select auth.uid()) or (select public.domu_is_admin()));

drop policy if exists "Only admins assign roles" on public.user_profiles;
create policy "Only admins assign roles"
  on public.user_profiles for update to authenticated
  using ((select public.domu_is_admin()))
  with check ((select public.domu_is_admin()));

-- Crie a primeira conta pela tela e confirme o e-mail.
-- Depois execute com o endereço dessa conta para habilitar o painel admin:
-- update public.user_profiles set role = 'admin', approved_at = now() where email = 'seu@email.com';
