import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = url && anonKey ? createClient(url, anonKey) : null;

export interface UserProfile {
  id: string;
  email: string;
  nome: string;
  role: 'morador' | 'sindico' | 'portaria' | 'admin';
  requested_role: 'morador' | 'sindico' | 'portaria' | null;
  approved_at: string | null;
  created_at: string;
}
