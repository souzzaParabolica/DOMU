import { useState, useEffect, useRef } from 'react';
import { Eclipse, Bell, LogOut } from 'lucide-react';
import { useStore } from '../store';
import { formatDataHora } from '../lib/format';
import type { Profile } from '../types';

const perfilNomes: Record<Profile, string> = {
  morador: 'Morador',
  sindico: 'Síndico(a)',
  portaria: 'Portaria',
};

export function TopBar({ onSair }: { onSair: () => void }) {
  const {
    state,
    toggleTema,
    marcarNotificacoesLidas,
    limparNotificacoes,
  } = useStore();
  const [notifOpen, setNotifOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  const eu = state.residents.find((r) => r.id === state.moradorAtualId);

  const notifs = state.notifications.filter(
    (n) =>
      n.targetProfile === state.perfilAtivo &&
      (!n.targetUnidadeId ||
        state.perfilAtivo !== 'morador' ||
        n.targetUnidadeId === eu?.unidadeId),
  );
  const naoLidas = notifs.filter((n) => !n.lida).length;

  useEffect(() => {
    const onClick = (e: Event) => {
      const alvo = e.target as Node;
      if (notifRef.current && !notifRef.current.contains(alvo)) setNotifOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    document.addEventListener('touchstart', onClick);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('touchstart', onClick);
    };
  }, []);

  return (
    <header className="surface sticky top-0 z-30 mb-4 flex items-center gap-1.5 rounded-b-2xl px-3 py-2.5 sm:gap-2 sm:px-4 sm:py-3">
      <span className="text-lg font-extrabold tracking-tight text-strong">DOMU</span>

      <div className="flex-1" />

      <button
        onClick={toggleTema}
        aria-label="Alternar tema claro/escuro"
        className="rounded-full p-2 text-strong hover:text-[#FE4E02]"
      >
        <Eclipse size={19} />
      </button>

      <div className="relative" ref={notifRef}>
        <button
          onClick={() => {
            const abrindo = !notifOpen;
            setNotifOpen(abrindo);
            if (abrindo && naoLidas > 0) marcarNotificacoesLidas(state.perfilAtivo);
          }}
          aria-label="Notificações"
          className="relative rounded-full p-2 text-strong hover:text-[#FE4E02]"
        >
          <Bell size={19} />
          {naoLidas > 0 && (
            <span
              className="absolute right-1.5 top-1.5 h-2.5 w-2.5 rounded-full bg-[#FE4E02]"
              aria-hidden="true"
            />
          )}
        </button>
        {notifOpen && (
          <div
            className="surface fixed right-2 top-14 w-[calc(100vw-1.5rem)] max-w-72 rounded-2xl p-3 sm:absolute sm:right-0 sm:top-11 sm:w-72"
            style={{ background: 'var(--bg-page)' }}
          >
            <div className="mb-2 flex items-center justify-between">
              <p className="text-xs font-bold uppercase tracking-wide text-muted">Notificações</p>
              {notifs.length > 0 && (
                <button onClick={limparNotificacoes} className="text-xs font-semibold text-[#FE4E02]">
                  Limpar
                </button>
              )}
            </div>
            {notifs.length === 0 && <p className="py-4 text-center text-sm text-muted">Nada por aqui.</p>}
            <div className="max-h-64 space-y-2 overflow-y-auto">
              {notifs.map((n) => (
                <div key={n.id} className="inset rounded-xl p-3">
                  <p className="text-sm font-semibold text-strong">{n.titulo}</p>
                  <p className="text-xs text-muted">{n.corpo}</p>
                  <p className="mt-1 text-[10px] text-muted">{formatDataHora(n.criadoEm)}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <span className="surface-soft rounded-full px-2.5 py-2 text-xs font-bold text-strong sm:px-3 sm:text-sm">
        {perfilNomes[state.perfilAtivo]}
      </span>
      <button
        onClick={onSair}
        aria-label="Sair da conta"
        title="Sair"
        className="rounded-full p-2 text-strong hover:text-[#FE4E02]"
      >
        <LogOut size={18} />
      </button>
    </header>
  );
}
