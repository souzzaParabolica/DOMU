import { useCallback, useEffect, useState } from 'react';
import { ArrowLeft, Building2, Check, ChevronDown, CircleUserRound, LogOut, RefreshCw, ShieldCheck, Users } from 'lucide-react';
import type { UserProfile } from '../lib/supabase';

const roleLabels: Record<UserProfile['role'], string> = { morador: 'Morador', sindico: 'Síndico', portaria: 'Portaria', admin: 'Administrador' };
const roles: UserProfile['role'][] = ['morador', 'sindico', 'portaria', 'admin'];

export default function AdminUsers({ admin, onSair }: { admin: UserProfile; onSair: () => void }) {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState('');

  const load = useCallback(async () => {
    setLoading(true); setError('');
    const { supabase } = await import('../lib/supabase');
    if (!supabase) { setError('Supabase não está configurado.'); setLoading(false); return; }
    const { data, error: queryError } = await supabase.from('user_profiles').select('*').order('created_at', { ascending: false });
    if (queryError) setError(queryError.message); else setUsers((data ?? []) as UserProfile[]);
    setLoading(false);
  }, []);

  useEffect(() => { void load(); }, [load]);

  const changeRole = async (user: UserProfile, role: UserProfile['role']) => {
    setSaved(''); setError('');
    const { supabase } = await import('../lib/supabase');
    if (!supabase) return;
    const { error: updateError } = await supabase.from('user_profiles').update({ role, approved_at: new Date().toISOString() }).eq('id', user.id);
    if (updateError) setError(updateError.message);
    else { setUsers((all) => all.map((item) => item.id === user.id ? { ...item, role, approved_at: new Date().toISOString() } : item)); setSaved(`Acesso de ${user.nome || user.email} atualizado.`); }
  };

  const pending = users.filter((user) => user.requested_role && user.role !== user.requested_role && user.role === 'morador').length;
  return <div className="min-h-screen bg-[#f7f6f3] px-4 py-6 text-[#1e211e] sm:px-8">
    <header className="mx-auto flex max-w-5xl items-center justify-between"><a href="#" className="flex items-center gap-2.5 text-[#1e302d]"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#c86648] text-white"><Building2 size={20} /></span><span className="text-lg font-extrabold tracking-tight">DOMU <span className="font-medium text-[#7d847e]">/ Admin</span></span></a><div className="flex items-center gap-3"><span className="hidden text-sm text-[#6f7770] sm:block">{admin.nome || admin.email}</span><button onClick={onSair} className="flex items-center gap-2 rounded-xl border border-[#e5e4df] bg-white px-3 py-2 text-sm font-medium hover:bg-[#f0efeb]"><LogOut size={16} /> Sair</button></div></header>
    <main className="mx-auto mt-10 max-w-5xl">
      <div className="mb-7 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="mb-2 text-xs font-bold uppercase tracking-[.16em] text-[#bd5b3d]">Administração</p><h1 className="text-3xl font-semibold tracking-tight">Acessos do condomínio</h1><p className="mt-2 text-sm text-[#737a74]">Revise solicitações e escolha o perfil de cada conta.</p></div><button onClick={() => void load()} className="flex w-fit items-center gap-2 rounded-xl border border-[#e5e4df] bg-white px-3.5 py-2.5 text-sm font-medium hover:bg-[#f0efeb]"><RefreshCw size={16} /> Atualizar lista</button></div>
      <div className="mb-6 grid gap-3 sm:grid-cols-3"><div className="rounded-2xl border border-[#e8e5df] bg-white p-4"><div className="flex items-center gap-2 text-sm text-[#707771]"><Users size={17} /> Contas cadastradas</div><p className="mt-2 text-2xl font-semibold">{users.length}</p></div><div className="rounded-2xl border border-[#e8e5df] bg-white p-4"><div className="flex items-center gap-2 text-sm text-[#707771]"><ShieldCheck size={17} /> Solicitações pendentes</div><p className="mt-2 text-2xl font-semibold">{pending}</p></div><div className="rounded-2xl border border-[#e8e5df] bg-white p-4"><div className="flex items-center gap-2 text-sm text-[#707771]"><CircleUserRound size={17} /> Seu perfil</div><p className="mt-2 text-base font-semibold">Administrador</p></div></div>
      {saved && <p role="status" className="mb-4 flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800"><Check size={17} />{saved}</p>}{error && <p role="alert" className="mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</p>}
      <section className="overflow-hidden rounded-2xl border border-[#e8e5df] bg-white"><div className="flex items-center justify-between border-b border-[#eeede8] px-5 py-4"><div><h2 className="font-semibold">Usuários</h2><p className="mt-0.5 text-xs text-[#858b85]">Funções e solicitações de acesso</p></div><span className="rounded-full bg-[#f4f2ed] px-2.5 py-1 text-xs font-semibold text-[#5c655e]">{users.length}</span></div>
        {loading ? <div className="p-10 text-center text-sm text-[#7b817c]">Carregando usuários…</div> : users.length === 0 ? <div className="p-10 text-center text-sm text-[#7b817c]">Nenhuma conta encontrada.</div> : <div className="divide-y divide-[#eeede8]">{users.map((user) => { const isPending = user.requested_role && user.role === 'morador' && user.requested_role !== 'morador'; return <div key={user.id} className="flex flex-col gap-4 px-5 py-4 sm:flex-row sm:items-center"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#f4eee8] font-semibold text-[#a6533a]">{(user.nome || user.email).slice(0, 1).toUpperCase()}</div><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold">{user.nome || 'Sem nome'} {isPending && <span className="ml-2 rounded-full bg-amber-50 px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-amber-800">Aguardando aprovação</span>}</p><p className="truncate text-xs text-[#818781]">{user.email}</p>{isPending && <p className="mt-1 text-xs text-[#a95036]">Solicitou acesso como {roleLabels[user.requested_role!]}</p>}</div><label className="relative flex items-center"><span className="sr-only">Cargo de {user.nome || user.email}</span><select value={user.role} onChange={(e) => void changeRole(user, e.target.value as UserProfile['role'])} disabled={user.id === admin.id} className="h-10 min-w-44 appearance-none rounded-xl border border-[#e6e4df] bg-white pl-3 pr-9 text-sm font-medium outline-none focus:border-[#c86b4f] disabled:opacity-50">{roles.map((role) => <option key={role} value={role}>{roleLabels[role]}</option>)}</select><ChevronDown size={15} className="pointer-events-none absolute right-3 text-[#777e78]" /></label></div>; })}</div>}
      </section>
      <p className="mt-5 text-xs leading-5 text-[#858b85]">As alterações de cargo são aplicadas imediatamente e protegidas pelas permissões do Supabase.</p>
    </main>
  </div>;
}
