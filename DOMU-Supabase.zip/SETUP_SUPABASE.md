﻿# DOMU com Supabase e GitHub Pages

O DOMU usa o projeto Supabase `lktpraynmhcuwmhlhktn`. A URL e a chave publicável estão configuradas em `.env.local` para desenvolvimento. Não coloque chaves secretas do Supabase no navegador nem no repositório.

## Banco e autenticação

- `supabase/schema.sql` define `public.user_profiles`, cargos, criação automática de perfis, políticas RLS e controles de administração. Esse SQL já foi aplicado ao projeto DOMU.
- A Data API está habilitada. `public.user_profiles` tem leitura e atualização para usuários autenticados, com RLS restringindo o acesso às linhas e operações permitidas.
- O Site URL e o redirecionamento do Auth apontam para `https://souzzaparabolica.github.io/DOMU/`; `localhost` foi removido da lista.
- O login e o cadastro usam Supabase Auth; as senhas não são armazenadas na tabela de perfis.
- Cadastros de síndico e portaria aguardam aprovação. Administradores são promovidos no banco, nunca por cadastro aberto.

## Publicar no GitHub Pages

O workflow `.github/workflows/deploy.yml` publica a branch `main` automaticamente. No repositório `souzzaParabolica/DOMU`, habilite **Settings → Pages → Build and deployment → GitHub Actions**. O endereço esperado é:

`https://souzzaparabolica.github.io/DOMU/`

O build já usa o caminho `/DOMU/` no GitHub Actions. O Supabase já está configurado com o Site URL acima e o Redirect URL `https://souzzaparabolica.github.io/DOMU/**`.

As variáveis do frontend precisam existir também durante o build do GitHub Actions. Adicione em **Settings → Secrets and variables → Actions → Variables**:

- `VITE_SUPABASE_URL` = `https://lktpraynmhcuwmhlhktn.supabase.co`
- `VITE_SUPABASE_ANON_KEY` = a chave `publishable` do projeto

O workflow já passa essas duas variáveis ao build. A chave publishable pode ser incluída no cliente; nunca use a chave `secret`/service role.

## Desenvolvimento

```powershell
npm install
npm run dev
```

Para rodar em outro provedor estático, configure `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` como variáveis de build e cadastre o domínio publicado em Authentication → URL Configuration. Nesse caso, use base `/`.

## Primeiro administrador

1. Cadastre a conta do administrador pelo app e confirme o e-mail, se essa opção estiver ativa.
2. No SQL Editor do Supabase, promova o endereço exato:

```sql
update public.user_profiles
set role = 'admin', approved_at = now()
where email = 'seu@email.com';
```

3. Entre no app escolhendo **Administrador**. A partir daí, aprove solicitações e defina os cargos.
