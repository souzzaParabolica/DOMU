gsap.registerPlugin(ScrollTrigger);

document.addEventListener("DOMContentLoaded", () => {
  const mm = gsap.matchMedia();

  // Respeita a preferência do usuário por movimento reduzido
  mm.add("(prefers-reduced-motion: no-preference)", () => {

    // 1. Entrada do cabeçalho
    const intro = gsap.timeline({
      defaults: {
        ease: "power3.out",
        duration: 0.65
      }
    });

    intro
      .from("header h2, header p", {
        opacity: 0,
        y: 10,
        stagger: 0.08
      }, "-=0.35")

    // 2. Entrada suave dos cards ao entrar na tela
    gsap.utils.toArray(".reveal-card").forEach((card) => {
      gsap.from(card, {
        opacity: 0,
        y: 22,
        scale: 0.985,
        duration: 0.65,
        ease: "power2.out",
        scrollTrigger: {
          trigger: card,
          start: "top 94%",
          toggleActions: "play none none none"
        },
        clearProps: "opacity,transform"
      });
    });

    // 3. Microinteração nos ícones decorativos
    gsap.utils.toArray(
      ".card > i, .card .profile"
    ).forEach((icon) => {
      gsap.from(icon, {
        opacity: 0,
        scale: 0.88,
        duration: 0.7,
        ease: "back.out(1.4)",
        delay: 0.12,
        scrollTrigger: {
          trigger: icon.closest(".card"),
          start: "top 94%",
          toggleActions: "play none none none"
        }
      });
    });

  });

  // Atualiza as posições dos gatilhos após o carregamento
  window.addEventListener("load", () => {
    ScrollTrigger.refresh();
  });
});

let tema = document.getElementById("scheme")
let html = document.documentElement
tema.addEventListener("click", () => {
  if(html.classList.contains("dark")){
    html.classList.remove("dark")
  }
  else{
    html.classList.add("dark")
  }
})